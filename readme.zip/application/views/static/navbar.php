<header id="header" class="header d-flex align-items-center">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

      <a href="index.html" class="logo d-flex align-items-center">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        <img src="<?php echo base_url();?>assets/logo.jpg" alt="logo" class="rounded-2">
        <h1>Mee Pham Drimed Law Office<span>.</span></h1>
      </a>

      <i class="mobile-nav-toggle mobile-nav-show bi bi-list"></i>
      <i class="mobile-nav-toggle mobile-nav-hide d-none bi bi-x"></i>
      <nav id="navbar" class="navbar fixed">
        <ul>
          <li><a href="<?php echo site_url('pages/index'); ?>" class="active">Home</a></li>
          <li><a href="<?php echo site_url('pages/about'); ?>">About</a></li>
          <li><a href="<?php echo site_url('pages/login'); ?>">Login</a></li>
       
        </ul>
      </nav><!-- .navbar -->

    </div>
  </header>